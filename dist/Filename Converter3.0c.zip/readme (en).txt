MORE HELP: http://nameconverter.aypac.de

_RUN PROGRAM_
_____________
	Extract and Double-click "Filename Converter 3.0c.jar".


_WHAT TO DO IF THIS PROGRAM DOESN'T WORK?_
__________________________________________
 _first_
  First make sure that a Java runtime enviromenent is installed!
  You should have "Version 6 Update 17" or higher!
	You can download it for free from:
         http://www.java.com/en/download/manual.jsp

 _still doesn't work?_
  You'll find some help documented on nameconverter.aypac.de
  Contact me: filenameconverter@aypac.de (english or german).



_LICENSE_
_________
 _gnu_
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
